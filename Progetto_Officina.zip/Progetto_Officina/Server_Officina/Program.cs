﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Server_Officina
{
    public class SynchronousSocketListener
    {
        public static void StartListening()
        {
            byte[] bytes = new byte[1024];
            IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 5000);
            Socket listener = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                Console.WriteLine("Server in ascolto...");

                while (true)
                {
                    Socket handler = listener.Accept();
                    Console.WriteLine("Connessione accettata da: {0}", handler.RemoteEndPoint.ToString());

                    // Avvia un nuovo thread per gestire la connessione
                    Thread clientThread = new Thread(() => HandleClient(handler));
                    clientThread.Start();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Errore: {0}", e.ToString());
            }
        }

        private static void HandleClient(Socket handler)
        {
            byte[] bytes = new byte[2048];
            try
            {
                while (handler.Connected)
                {
                    try
                    {
                        int bytesRec = handler.Receive(bytes);
                        string data = Encoding.ASCII.GetString(bytes, 0, bytesRec);

                        if (data.StartsWith("Login:"))
                        {
                            string[] credentials = data.Substring(6).Split(';');
                            string username = credentials[0];
                            string password = credentials[1];

                            // Verifica nel file se le credenziali esistono
                            bool loginSuccess = VerificaCredenziali(username, password);
                            string response = loginSuccess ? "LoginSuccesso" : "LoginFallito";

                            byte[] msg = Encoding.ASCII.GetBytes(response);
                            handler.Send(msg);

                            if (loginSuccess)
                            {
                                Console.WriteLine($"Utente '{username}' connesso al server.");
                            }
                        }
                        else if (data == "ChiudiConnessione")
                        {
                            Console.WriteLine("Il client ha chiuso la connessione.");
                            handler.Shutdown(SocketShutdown.Both);
                            handler.Close();
                            break;
                        }
                        else if (data.StartsWith("Servizio:"))
                        {
                            string fileName = data.Substring(11) + ".txt";
                            string filePath = ($@"..\..\Properties\{fileName}");
                            string response;

                            try
                            {
                                response = File.Exists(filePath) ? File.ReadAllText(filePath) : "FileNonTrovato";
                            }
                            catch (Exception ex)
                            {
                                response = $"Errore:{ex.Message}";
                            }

                            byte[] msg = Encoding.ASCII.GetBytes(response);
                            handler.Send(msg);
                        }
                        else if (data.StartsWith("Acquista:"))
                        {
                            string[] parti = data.Substring(9).Split(';');
                            string username = parti[0];
                            string componente = parti[1];
                            decimal prezzo = decimal.Parse(parti[2]);

                            string saldoStr = OttieniSaldo(username);
                            decimal saldo = decimal.Parse(saldoStr);

                            if (saldo >= prezzo)
                            {
                                bool successo = AggiornaSaldo(username, -prezzo);
                                SalvaAcquisto(username, componente, prezzo);
                                string risposta = successo ? "AcquistoSuccesso" : "ErroreAcquisto";
                                byte[] msg = Encoding.ASCII.GetBytes(risposta);
                                handler.Send(msg);
                            }
                            else
                            {
                                byte[] msg = Encoding.ASCII.GetBytes("SaldoInsufficiente");
                                handler.Send(msg);
                            }
                        }
                        else if (data.StartsWith("Acquisti:"))
                        {
                            string username = data.Substring(9);
                            string acquistiFilePath = @"..\..\Properties\Acquisti.txt";
                            string response = "";

                            try
                            {
                                if (File.Exists(acquistiFilePath))
                                {
                                    foreach (var line in File.ReadLines(acquistiFilePath))
                                    {
                                        var parts = line.Split(';');
                                        if (parts.Length >= 2 && parts[0] == username)
                                        {
                                            response += $"{parts[1]} - {parts[2]} euro \n";
                                        }
                                    }

                                    if (string.IsNullOrEmpty(response))
                                    {
                                        response = "Nessun acquisto trovato.";
                                    }
                                }
                                else
                                {
                                    response = "FileNonTrovato";
                                }
                            }
                            catch (Exception ex)
                            {
                                response = $"Errore:{ex.Message}";
                            }

                            byte[] msg = Encoding.ASCII.GetBytes(response);
                            handler.Send(msg);
                        }
                        else if (data.StartsWith("Recensione:"))
                        {
                            string[] parti = data.Substring(11).Split(';');
                            if (parti.Length >= 3)
                            {
                                string username = parti[0];
                                string valutazione = parti[1];
                                string commento = parti[2];

                                bool successo = SalvaRecensione(username, valutazione, commento);
                                string risposta = successo ? "RecensioneAggiunta" : "ErroreAggiuntaRecensione";

                                byte[] msg = Encoding.ASCII.GetBytes(risposta);
                                handler.Send(msg);
                            }
                            else
                            {
                                byte[] msg = Encoding.ASCII.GetBytes("ErroreDatiRecensione");
                                handler.Send(msg);
                            }
                        }
                        else if (data == "VisualizzaRecensioni")
                        {
                            string recensioniFilePath = @"..\..\Properties\Recensioni.txt";
                            string response;

                            try
                            {
                                if (File.Exists(recensioniFilePath))
                                {
                                    // Leggi tutte le recensioni
                                    response = File.ReadAllText(recensioniFilePath);
                                }
                                else
                                {
                                    response = "FileNonTrovato";
                                }
                            }
                            catch (Exception ex)
                            {
                                response = $"Errore:{ex.Message}";
                            }

                            byte[] msg = Encoding.ASCII.GetBytes(response);
                            handler.Send(msg);
                        }
                        else if (data.StartsWith("Ricarica:"))
                        {
                            string[] parti = data.Substring(9).Split(';');
                            string username = parti[0];
                            decimal importo = decimal.Parse(parti[1]);

                            bool successo = AggiornaSaldo(username, importo);
                            string risposta = successo ? "RicaricaSuccesso" : "RicaricaFallita";
                            byte[] msg = Encoding.ASCII.GetBytes(risposta);
                            handler.Send(msg);
                        }
                        else if (data.StartsWith("Saldo:"))
                        {
                            string username = data.Substring(6);
                            string saldo = OttieniSaldo(username);
                            byte[] msg = Encoding.ASCII.GetBytes(saldo);
                            handler.Send(msg);
                        }
                        else
                        {
                            SalvaDatiUtente(data);
                        }
                    }
                    catch
                    {
                        Console.WriteLine("Errore durante la comunicazione con il client.");
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante la gestione del client: " + ex.Message);
            }
            finally
            {
                handler.Close();
            }
        }

        private static bool VerificaCredenziali(string username, string password)
        {
            string filePath = @"..\..\Properties\Datiutenti.txt";
            try
            {
                foreach (var line in File.ReadLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 2 && parts[0] == username && parts[1] == password)
                    {
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante la verifica delle credenziali: " + ex.Message);
            }
            return false;
        }

        private static void SalvaDatiUtente(string userData)
        {
            string filePath = @"..\..\Properties\Datiutenti.txt";
            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, append: true))
                {
                    writer.WriteLine(userData);
                }
                Console.WriteLine("Dati utente salvati nel file.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante il salvataggio dei dati: " + ex.Message);
            }
        }

        private static void SalvaAcquisto(string username, string componente, decimal prezzo)
        {
            string acquistiFilePath = @"..\..\Properties\Acquisti.txt";
            try
            {
                using (StreamWriter writer = new StreamWriter(acquistiFilePath, append: true))
                {
                    writer.WriteLine($"{username};{componente};{prezzo}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante il salvataggio dell'acquisto: " + ex.Message);
            }
        }
        private static bool SalvaRecensione(string username, string valutazione, string commento)
        {
            string recensioniFilePath = @"..\..\Properties\Recensioni.txt";
            try
            {
                using (StreamWriter writer = new StreamWriter(recensioniFilePath, append: true))
                {
                    writer.WriteLine($"{DateTime.Now};{username};{valutazione};{commento}");
                }
                Console.WriteLine("Recensione salvata correttamente.");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante il salvataggio della recensione: " + ex.Message);
                return false;
            }
        }

        private static string OttieniSaldo(string username)
        {
            string filePath = @"..\..\Properties\Datiutenti.txt";
            try
            {
                foreach (var line in File.ReadLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 3 && parts[0] == username)
                    {
                        return parts[2];
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante la lettura del saldo: " + ex.Message);
            }
            return "0";
        }

        private static bool AggiornaSaldo(string username, decimal importo)
        {
            string filePath = @"..\..\Properties\Datiutenti.txt";
            try
            {
                var lines = File.ReadAllLines(filePath);
                for (int i = 0; i < lines.Length; i++)
                {
                    var parts = lines[i].Split(';');
                    if (parts.Length >= 3 && parts[0] == username)
                    {
                        decimal saldoCorrente = decimal.Parse(parts[2]);
                        saldoCorrente += importo;
                        parts[2] = saldoCorrente.ToString();
                        lines[i] = string.Join(";", parts);
                        File.WriteAllLines(filePath, lines);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante l'aggiornamento del saldo: " + ex.Message);
            }
            return false;
        }

        public static void Main(String[] args)
        {
            StartListening();

        }
    }
}