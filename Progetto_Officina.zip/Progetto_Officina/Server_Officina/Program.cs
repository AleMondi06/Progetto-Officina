﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Server_Officina
{
    public class SynchronousSocketListener
    {
        public static void StartListening()
        {
            byte[] bytes = new byte[1024];
            IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 5000);
            Socket listener = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                Console.WriteLine("Server in ascolto...");

                while (true)
                {
                    Socket handler = listener.Accept();
                    Console.WriteLine("Connessione accettata da: {0}", handler.RemoteEndPoint.ToString());

                    while (handler.Connected)
                    {
                        try
                        {
                            int bytesRec = handler.Receive(bytes);
                            string data = Encoding.ASCII.GetString(bytes, 0, bytesRec);

                            if (data.StartsWith("Login:"))
                            {
                                string[] credentials = data.Substring(6).Split(';');
                                string username = credentials[0];
                                string password = credentials[1];

                                // Verifica nel file se le credenziali esistono
                                bool loginSuccess = VerificaCredenziali(username, password);
                                string response;
                                if (loginSuccess)
                                {
                                    response = "LoginSuccesso";
                                }
                                else
                                {
                                    response = "LoginFallito";
                                }

                                // Invia la risposta al client
                                byte[] msg = Encoding.ASCII.GetBytes(response);
                                handler.Send(msg);
                            }
                            else if (data == "ChiudiConnessione")
                            {
                                Console.WriteLine("Il client ha chiuso la connessione.");
                                handler.Shutdown(SocketShutdown.Both);
                                handler.Close();
                                break;
                            }
                            else
                            {
                                SalvaDatiUtente(data);
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Errore durante la comunicazione");
                            break;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Errore: {0}", e.ToString());
            }
        }

        private static bool VerificaCredenziali(string username, string password)
        {
            string filePath = @"..\..\Properties\Datiutenti.txt";

            try
            {
                foreach (var line in File.ReadLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 2 && parts[0] == username && parts[1] == password)
                    {
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante la verifica delle credenziali: " + ex.Message);
            }
            return false;
        }

        private static void SalvaDatiUtente(string userData)
        {
            string filePath = @"..\..\Properties\Datiutenti.txt";

            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, append: true))
                {
                    writer.WriteLine(userData);
                }

                Console.WriteLine("Dati utente salvati nel file.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante il salvataggio dei dati: " + ex.Message);
            }
        }

        public static void Main(String[] args)
        {
            StartListening();
        }
    }
}
