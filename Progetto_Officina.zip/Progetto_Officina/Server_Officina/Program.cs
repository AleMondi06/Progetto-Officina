﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Server_Officina
{
    public class SynchronousSocketListener
    {
        public static void StartListening()
        {
            // Buffer per i dati in arrivo
            byte[] bytes = new byte[1024];

            // Creazione del punto finale locale per il server
            IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 5000);

            // Creazione di un socket TCP/IP
            Socket listener = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            try
            {
                // Binding del socket al punto finale locale e avvio dell'ascolto
                listener.Bind(localEndPoint);
                listener.Listen(10);

                Console.WriteLine("Server in ascolto...");

                while (true)
                {
                    // Accetta una connessione in entrata
                    Socket handler = listener.Accept();
                    Console.WriteLine("Connessione accettata da: {0}", handler.RemoteEndPoint.ToString());

                    // Mantieni la connessione aperta finché il client non si disconnette
                    while (handler.Connected)
                    {
                        try
                        {
                            int bytesRec = handler.Receive(bytes);
                            string data = Encoding.ASCII.GetString(bytes, 0, bytesRec);

                            // Se il client invia il messaggio di disconnessione
                            if (data == "ChiudiConnessione")
                            {
                                Console.WriteLine("Il client ha chiuso la connessione.");
                                handler.Shutdown(SocketShutdown.Both);
                                handler.Close();
                                break;
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Errore durante la comunicazione con il client.");
                            break;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Errore: {0}", e.ToString());
            }
        }

        public static void Main(String[] args)
        {
            // Avvio del server
            StartListening();
        }
    }
}
