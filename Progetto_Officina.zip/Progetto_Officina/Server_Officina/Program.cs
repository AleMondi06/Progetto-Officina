﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Server_Officina
{
    public class SynchronousSocketListener
    {
        public static void StartListening()
        {
            byte[] bytes = new byte[1024];
            IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 5000);
            Socket listener = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                Console.WriteLine("Server in ascolto...");

                while (true)
                {
                    Socket handler = listener.Accept();
                    Console.WriteLine("Connessione accettata da: {0}", handler.RemoteEndPoint.ToString());

                    while (handler.Connected)
                    {
                        try
                        {
                            int bytesRec = handler.Receive(bytes);
                            string data = Encoding.ASCII.GetString(bytes, 0, bytesRec);

                            if (data.StartsWith("Login:"))
                            {
                                string[] credentials = data.Substring(6).Split(';');
                                string username = credentials[0];
                                string password = credentials[1];

                                // Verifica nel file se le credenziali esistono
                                bool loginSuccess = VerificaCredenziali(username, password);
                                string response;
                                if (loginSuccess)
                                {
                                    response = "LoginSuccesso";
                                }
                                else
                                {
                                    response = "LoginFallito";
                                }

                                // Invia la risposta al client
                                byte[] msg = Encoding.ASCII.GetBytes(response);
                                handler.Send(msg);
                            }         
                            else if (data == "ChiudiConnessione")
                            {
                                Console.WriteLine("Il client ha chiuso la connessione.");
                                handler.Shutdown(SocketShutdown.Both);
                                handler.Close();
                                break;
                            }
                            else if (data.StartsWith("Richiesta:"))
                            {
                                string fileName = data.Substring(10) + ".txt"; // Estrae il nome del file (es. Revisione.txt)
                                string filePath = ($@"..\..\Properties\{fileName}"); // Percorso del file
                                string response;

                                try
                                {
                                    if (File.Exists(filePath))
                                    {
                                        response = File.ReadAllText(filePath); // Legge tutto il contenuto del file
                                    }
                                    else
                                    {
                                        response = "FileNonTrovato"; // Risposta se il file non esiste
                                    }
                                }
                                catch (Exception ex)
                                {
                                    response = $"Errore:{ex.Message}"; // Risposta in caso di errore
                                }

                                // Invia la risposta al client
                                byte[] msg = Encoding.ASCII.GetBytes(response);
                                handler.Send(msg);
                            }
                            else if (data.StartsWith("Acquista:"))
                            {
                                // Estrai il nome utente, il componente e il prezzo dalla richiesta
                                string[] parti = data.Substring(9).Split(';');
                                string username = parti[0];
                                string componente = parti[1];
                                decimal prezzo = decimal.Parse(parti[2]);

                                // Verifica il saldo dell'utente
                                string saldoStr = OttieniSaldo(username);
                                decimal saldo = decimal.Parse(saldoStr);

                                if (saldo >= prezzo)
                                {
                                    // Se l'utente ha abbastanza soldi, aggiorna il saldo
                                    bool successo = AggiornaSaldo(username, -prezzo); // Sottrarre il prezzo dall'importo

                                    // Risposta positiva se l'acquisto è stato completato
                                    string risposta = successo ? "AcquistoSuccesso" : "ErroreAcquisto";
                                    byte[] msg = Encoding.ASCII.GetBytes(risposta);
                                    handler.Send(msg);
                                }
                                else
                                {
                                    // Se non ha abbastanza soldi, invia un messaggio di errore
                                    byte[] msg = Encoding.ASCII.GetBytes("SaldoInsufficiente");
                                    handler.Send(msg);
                                }
                            }
                            else if (data.StartsWith("Ricarica:"))
                            {
                                // Estrai il nome utente e l'importo dalla richiesta
                                string[] parti = data.Substring(9).Split(';');
                                string username = parti[0];
                                decimal importo = decimal.Parse(parti[1]);

                                // Aggiorna il saldo nel file
                                bool successo = AggiornaSaldo(username, importo);

                                // Invia una risposta al client
                                string risposta = successo ? "RicaricaSuccesso" : "RicaricaFallita";
                                byte[] msg = Encoding.ASCII.GetBytes(risposta);
                                handler.Send(msg);
                            }
                            else if (data.StartsWith("Saldo:"))
                            {
                                // Estrai il nome utente dalla richiesta
                                string username = data.Substring(6);

                                // Ottieni il saldo dal file
                                string saldo = OttieniSaldo(username);

                                // Invia il saldo al client
                                byte[] msg = Encoding.ASCII.GetBytes(saldo);
                                handler.Send(msg);
                            }
                            else
                            {
                                SalvaDatiUtente(data);
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Errore durante la comunicazione");
                            break;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Errore: {0}", e.ToString());
            }
        }

        private static bool VerificaCredenziali(string username, string password)
        {
            string filePath = @"..\..\Properties\Datiutenti.txt";

            try
            {
                foreach (var line in File.ReadLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 2 && parts[0] == username && parts[1] == password)
                    {
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante la verifica delle credenziali: " + ex.Message);
            }
            return false;
        }

        private static void SalvaDatiUtente(string userData)
        {
            string filePath = @"..\..\Properties\Datiutenti.txt";

            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, append: true))
                {
                    writer.WriteLine(userData);
                }

                Console.WriteLine("Dati utente salvati nel file.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante il salvataggio dei dati: " + ex.Message);
            }
        }
        
        private static string OttieniSaldo(string username)
        {
            string filePath = @"..\..\Properties\Datiutenti.txt";

            try
            {
                foreach (var line in File.ReadLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 3 && parts[0] == username)
                    {
                        // Il saldo è la terza colonna
                        return parts[2];
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante la lettura del saldo: " + ex.Message);
            }

            // Se non trovato, restituisce 0
            return "0";
        }
        private static bool AggiornaSaldo(string username, decimal importo)
        {
            string filePath = @"..\..\Properties\Datiutenti.txt";

            try
            {
                var lines = File.ReadAllLines(filePath);
                for (int i = 0; i < lines.Length; i++)
                {
                    var parts = lines[i].Split(';');
                    if (parts.Length >= 3 && parts[0] == username)
                    {
                        // Aggiorna il saldo
                        decimal saldoCorrente = decimal.Parse(parts[2]);
                        saldoCorrente += importo;
                        parts[2] = saldoCorrente.ToString();

                        // Ricostruisci la riga e aggiorna il file
                        lines[i] = string.Join(";", parts);
                        File.WriteAllLines(filePath, lines);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante l'aggiornamento del saldo: " + ex.Message);
            }

            return false;
        }

        public static void Main(String[] args)
        {
            StartListening();
        }
    }
}
