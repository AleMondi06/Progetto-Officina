﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Client_Officina
{
    public partial class Form2 : Form
    {
        private Socket senderSocket;
        private string username; // Nome dell'utente connesso

        public Form2(Socket socket, string username)
        {
            InitializeComponent();
            senderSocket = socket;
            this.username = username; // Memorizza il nome utente
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            CB_Servizio.Items.Clear();
            CB_Servizio.Items.Add("--Revisione");
            CB_Servizio.Items.Add("--Sostituzione");
            CB_Servizio.Items.Add("--Acquisto");
            AggiornaSaldo();

        }

        private void Exit_Client_Click(object sender, EventArgs e)
        {
            try
            {
                if (senderSocket != null && senderSocket.Connected)
                {
                    // Invia un messaggio di chiusura al server
                    byte[] closeMsg = Encoding.ASCII.GetBytes("ChiudiConnessione");
                    senderSocket.Send(closeMsg);

                    // Chiude la connessione
                    senderSocket.Shutdown(SocketShutdown.Both);
                    senderSocket.Close();
                    senderSocket = null; // Resetta il socket
                    MessageBox.Show("Connessione chiusa con il server");
                }

                // Torna a Form1
                Form1 form1 = new Form1();
                form1.Show();
                this.Hide(); // Chiude Form2
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la chiusura della connessione: " + ex.Message);
            }
        }

        private void BTN_AreaUtente_Click(object sender, EventArgs e)
        {
            // Passa il nome utente anche a Form3
            Form3 form3 = new Form3(senderSocket, username);
            form3.Show();
            this.Hide();
        }

        private void CB_Servizio_SelectedIndexChanged(object sender, EventArgs e)
        {
            string servizioSelezionato = CB_Servizio.SelectedItem.ToString();

            try
            {
                // Invio della richiesta al server
                string richiesta = $"Servizio:{servizioSelezionato}";
                byte[] msg = Encoding.ASCII.GetBytes(richiesta);
                senderSocket.Send(msg);

                // Ricezione della risposta
                byte[] buffer = new byte[2048];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                if (risposta == "FileNonTrovato")
                {
                    MessageBox.Show("Il file richiesto non è stato trovato.");
                    return;
                }

                if (risposta.StartsWith("Errore"))
                {
                    MessageBox.Show("Errore del server: " + risposta);
                    return;
                }

                // Processa i dati ricevuti
                AggiornaLabel(risposta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la comunicazione col server: " + ex.Message);
            }
        }

        private void AggiornaLabel(string dati)
        {
            string[] righe = dati.Split('\n');

            foreach (string riga in righe)
            {
                string[] campi = riga.Split(';');
                if (campi.Length != 2) continue;

                string componente = campi[0];
                string prezzo = campi[1];
                switch (componente.ToLower())
                {
                    case "motore":
                        PrezzoMotore.Text = $"Prezzo: {prezzo}";
                        break;

                    case "sterzo":
                        PrezzoSterzo.Text = $"Prezzo: {prezzo}";
                        break;

                    case "freni":
                        PrezzoFreni.Text = $"Prezzo: {prezzo}";
                        break;

                    case "sospensioni":
                        PrezzoSospensioni.Text = $"Prezzo: {prezzo}";
                        break;

                    case "spie":
                        PrezzoSpie.Text = $"Prezzo: {prezzo}";
                        break;

                    case "vetri":
                        PrezzoVetri.Text = $"Prezzo: {prezzo}";
                        break;
                }
            }
        }
        private void AggiornaSaldo()
        {
            try
            {
                // Invia la richiesta di saldo al server
                string richiesta = $"Saldo:{username}";
                byte[] msg = Encoding.ASCII.GetBytes(richiesta);
                senderSocket.Send(msg);

                // Riceve la risposta dal server
                byte[] buffer = new byte[1024];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                // Aggiorna la label con il saldo
                LabelSaldo.Text = $"Saldo: {risposta} €";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante l'aggiornamento del saldo: " + ex.Message);
            }
        }

        private void BTN_Acquisti_Click(object sender, EventArgs e)
        {

            try
            {
                // Invia una richiesta al server per gli acquisti
                string richiesta = $"Acquisti:{username}";
                byte[] msg = Encoding.ASCII.GetBytes(richiesta);
                senderSocket.Send(msg);

                // Ricevi la risposta dal server
                byte[] buffer = new byte[2048];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                if (risposta == "FileNonTrovato")
                {
                    MessageBox.Show("La cronologia degli acquisti non è stata trovata.");
                    return;
                }

                if (risposta.StartsWith("Errore"))
                {
                    MessageBox.Show("Errore del server: " + risposta);
                    return;
                }

                // Mostra gli acquisti nella TextBox
                MessageBox.Show($"{risposta}");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la comunicazione col server: " + ex.Message);
            }
        }
        private void MotoreButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Estrai il prezzo del motore dalla label
                decimal prezzo = decimal.Parse(PrezzoMotore.Text.Replace("Prezzo: ", ""));
                string richiesta = $"Acquista:{username};motore;{prezzo}"; // Formato: Acquista:username;componente;prezzo

                // Invia la richiesta di acquisto al server
                byte[] msg = Encoding.ASCII.GetBytes(richiesta);
                senderSocket.Send(msg);

                // Ricevi la risposta dal server
                byte[] buffer = new byte[2048];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                if (risposta == "AcquistoSuccesso")
                {
                    MessageBox.Show("Acquisto completato con successo!");
                    AggiornaSaldo(); 
                }
                else if (risposta == "SaldoInsufficiente")
                {
                    MessageBox.Show("Saldo insufficiente per completare l'acquisto.");
                }
                else
                {
                    MessageBox.Show("Errore durante l'acquisto.");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Selezionare un servizio prima di acquistare");
            }
        }

        private void SterzoButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Estrai il prezzo dello sterzo dalla label
                decimal prezzo = decimal.Parse(PrezzoSterzo.Text.Replace("Prezzo: ", ""));
                string richiesta = $"Acquista:{username};sterzo;{prezzo}"; // Formato: Acquista:username;componente;prezzo

                // Invia la richiesta di acquisto al server
                byte[] msg = Encoding.ASCII.GetBytes(richiesta);
                senderSocket.Send(msg);

                // Ricevi la risposta dal server
                byte[] buffer = new byte[2048];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                if (risposta == "AcquistoSuccesso")
                {
                    MessageBox.Show("Acquisto completato con successo!");
                    AggiornaSaldo();
                }
                else if (risposta == "SaldoInsufficiente")
                {
                    MessageBox.Show("Saldo insufficiente per completare l'acquisto.");
                }
                else
                {
                    MessageBox.Show("Errore durante l'acquisto.");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Selezionare un servizio prima di acquistare");
            }
        }

        private void FreniButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Estrai il prezzo dei freni dalla label
                decimal prezzo = decimal.Parse(PrezzoFreni.Text.Replace("Prezzo: ", ""));
                string richiesta = $"Acquista:{username};freni;{prezzo}"; // Formato: Acquista:username;componente;prezzo

                // Invia la richiesta di acquisto al server
                byte[] msg = Encoding.ASCII.GetBytes(richiesta);
                senderSocket.Send(msg);

                // Ricevi la risposta dal server
                byte[] buffer = new byte[2048];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                if (risposta == "AcquistoSuccesso")
                {
                    MessageBox.Show("Acquisto completato con successo!");
                    AggiornaSaldo();
                }
                else if (risposta == "SaldoInsufficiente")
                {
                    MessageBox.Show("Saldo insufficiente per completare l'acquisto.");
                }
                else
                {
                    MessageBox.Show("Errore durante l'acquisto.");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Selezionare un servizio prima di acquistare");
            }
        }

        private void SospensioniButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Estrai il prezzo delle sospensioni dalla label
                decimal prezzo = decimal.Parse(PrezzoSospensioni.Text.Replace("Prezzo: ", ""));
                string richiesta = $"Acquista:{username};sospensioni;{prezzo}"; // Formato: Acquista:username;componente;prezzo

                // Invia la richiesta di acquisto al server
                byte[] msg = Encoding.ASCII.GetBytes(richiesta);
                senderSocket.Send(msg);

                // Ricevi la risposta dal server
                byte[] buffer = new byte[2048];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                if (risposta == "AcquistoSuccesso")
                {
                    MessageBox.Show("Acquisto completato con successo!"); 
                    AggiornaSaldo();

                }
                else if (risposta == "SaldoInsufficiente")
                {
                    MessageBox.Show("Saldo insufficiente per completare l'acquisto.");
                }
                else
                {
                    MessageBox.Show("Errore durante l'acquisto.");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Selezionare un servizio prima di acquistare");
            }
        }

        private void SpieButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Estrai il prezzo delle spie dalla label
                decimal prezzo = decimal.Parse(PrezzoSpie.Text.Replace("Prezzo: ", ""));
                string richiesta = $"Acquista:{username};spie;{prezzo}"; // Formato: Acquista:username;componente;prezzo

                // Invia la richiesta di acquisto al server
                byte[] msg = Encoding.ASCII.GetBytes(richiesta);
                senderSocket.Send(msg);

                // Ricevi la risposta dal server
                byte[] buffer = new byte[2048];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                if (risposta == "AcquistoSuccesso")
                {
                    MessageBox.Show("Acquisto completato con successo!");
                    AggiornaSaldo();
                }
                else if (risposta == "SaldoInsufficiente")
                {
                    MessageBox.Show("Saldo insufficiente per completare l'acquisto.");
                }
                else
                {
                    MessageBox.Show("Errore durante l'acquisto.");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Selezionare un servizio prima di acquistare");
            }
        }

        private void VetroButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Estrai il prezzo del vetro dalla label
                decimal prezzo = decimal.Parse(PrezzoVetri.Text.Replace("Prezzo: ", ""));
                string richiesta = $"Acquista:{username};vetri;{prezzo}"; // Formato: Acquista:username;componente;prezzo

                // Invia la richiesta di acquisto al server
                byte[] msg = Encoding.ASCII.GetBytes(richiesta);
                senderSocket.Send(msg);

                // Ricevi la risposta dal server
                byte[] buffer = new byte[2048];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                if (risposta == "AcquistoSuccesso")
                {
                    MessageBox.Show("Acquisto completato con successo!");
                    AggiornaSaldo();
                }
                else if (risposta == "SaldoInsufficiente")
                {
                    MessageBox.Show("Saldo insufficiente per completare l'acquisto.");
                }
                else
                {
                    MessageBox.Show("Errore durante l'acquisto.");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Selezionare un servizio prima di acquistare");
            }
        }

        private void BTN_Recensioni_Click(object sender, EventArgs e)
        {
            try
            {
                // Richiedi una valutazione da 1 a 5
                string valutazioneStr = Interaction.InputBox("Inserisci una valutazione da 1 a 5:", "Aggiungi Recensione", "5");
                if (string.IsNullOrWhiteSpace(valutazioneStr) || !int.TryParse(valutazioneStr, out int valutazione) || valutazione < 1 || valutazione > 5)
                {
                    MessageBox.Show("Valutazione non valida. Inserire un numero tra 1 e 5.");
                    return;
                }

                // Richiedi un commento
                string commento = Interaction.InputBox("Inserisci un commento per la recensione:", "Aggiungi Recensione", "");
                if (string.IsNullOrWhiteSpace(commento))
                {
                    MessageBox.Show("Il commento non può essere vuoto.");
                    return;
                }

                // Prepara il messaggio da inviare al server
                string recensioneData = $"Recensione:{username};{valutazione};{commento}";
                byte[] msg = Encoding.ASCII.GetBytes(recensioneData);
                senderSocket.Send(msg);

                // Ricevi la conferma dal server
                byte[] buffer = new byte[1024];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                if (risposta == "RecensioneAggiunta")
                {
                    MessageBox.Show("Recensione aggiunta con successo!");
                }
                else
                {
                    MessageBox.Show("Errore durante l'aggiunta della recensione.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la comunicazione col server: " + ex.Message);
            }
        }


        private void BTN_VisRecensioni_Click(object sender, EventArgs e)
        {
            try
            {
                // Invia la richiesta al server per ottenere le recensioni
                string richiesta = "VisualizzaRecensioni";
                byte[] msg = Encoding.ASCII.GetBytes(richiesta);
                senderSocket.Send(msg);

                // Riceve la risposta dal server
                byte[] buffer = new byte[2048];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                if (risposta == "FileNonTrovato")
                {
                    MessageBox.Show("Non sono presenti recensioni al momento.");
                }
                else if (risposta.StartsWith("Errore"))
                {
                    MessageBox.Show("Errore durante il recupero delle recensioni: " + risposta);
                }
                else
                {
                    // Mostra le recensioni all'utente
                    MessageBox.Show("Recensioni:\n" + risposta, "Recensioni (Giorno e Orario, Utente, Valutazione, Commento)");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la comunicazione col server: " + ex.Message);
            }
        }
    }
}
