﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace Client_Officina
{
    public partial class Form2 : Form
    {
        private Socket senderSocket; // Variabile per il socket del client

        // Costruttore che accetta il socket
        public Form2(Socket socket)
        {
            InitializeComponent();
            senderSocket = socket;
        }

        private void Exit_Client_Click(object sender, EventArgs e)
        {
            try
            {
                if (senderSocket != null && senderSocket.Connected)
                {
                    // Invia un messaggio di chiusura al server
                    byte[] closeMsg = Encoding.ASCII.GetBytes("ChiudiConnessione");
                    senderSocket.Send(closeMsg);

                    // Chiude la connessione
                    senderSocket.Shutdown(SocketShutdown.Both);
                    senderSocket.Close();
                    senderSocket = null; // Resetta il socket
                    MessageBox.Show("Connessione chiusa con il server");
                }

                // Torna a Form1
                Form1 form1 = new Form1();
                form1.Show();
                this.Hide(); // Chiude Form2
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la chiusura della connessione: " + ex.Message);
            }
        }

        private void BTN_AreaUtente_Click(object sender, EventArgs e)
        {
            // Apertura di Form2 con il socket e nasconde Form1
            Form3 form3 = new Form3(senderSocket);
            form3.Show();
            this.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
