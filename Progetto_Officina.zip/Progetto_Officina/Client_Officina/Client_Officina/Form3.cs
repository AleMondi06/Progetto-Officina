﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client_Officina
{
    public partial class Form3 : Form
    {
        private Socket senderSocket;
        private string username; // Nome dell'utente connesso

        public Form3(Socket socket, string username)
        {
            InitializeComponent();
            senderSocket = socket;
            this.username = username;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // Modifica la label con il nome dell'utente
            label6.Text = $"Benvenuto, {username}!";
        }

        private void BTN_return_Click(object sender, EventArgs e)
        {
            // Torna a Form2 passando il socket corrente
            Form2 form2 = new Form2(senderSocket, username);
            form2.Show();
            this.Hide(); // Nasconde Form3
        }

        private void BTN_RicaricaConto_Click(object sender, EventArgs e)
        {
            string importo = Box_Importo.Text;

            // Controlla che l'importo sia valido
            if (string.IsNullOrWhiteSpace(importo) || !decimal.TryParse(importo, out decimal importoDecimal) || importoDecimal <= 0)
            {
                MessageBox.Show("Inserisci un importo valido maggiore di 0.", "Errore");
                return;
            }

            try
            {
                // Prepara il messaggio da inviare al server
                string richiestaRicarica = $"Ricarica:{username};{importo}";
                byte[] msg = Encoding.ASCII.GetBytes(richiestaRicarica);
                senderSocket.Send(msg);

                // Riceve la risposta dal server
                byte[] buffer = new byte[1024];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                if (risposta == "RicaricaSuccesso")
                {
                    MessageBox.Show($"Ricarica completata! Hai aggiunto {importo} € al tuo conto.", "Ricarica");
                }
                else
                {
                    MessageBox.Show("Errore durante la ricarica. Riprova più tardi.", "Errore");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Errore durante la ricarica del conto: {ex.Message}");
            }
        }


        private void BTN_VisConto_Click(object sender, EventArgs e)
        {
            try
            {
                // Invia la richiesta al server per ottenere il saldo
                string richiestaSaldo = $"Saldo:{username}";
                byte[] msg = Encoding.ASCII.GetBytes(richiestaSaldo);
                senderSocket.Send(msg);

                // Riceve il saldo dal server
                byte[] buffer = new byte[1024];
                int bytesRec = senderSocket.Receive(buffer);
                string risposta = Encoding.ASCII.GetString(buffer, 0, bytesRec);

                // Mostra il saldo nella label o in un MessageBox
                MessageBox.Show($"Il tuo saldo attuale è: {risposta} €", "Saldo Conto");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Errore durante la visualizzazione del saldo: {ex.Message}");
            }
        }

    }
}
