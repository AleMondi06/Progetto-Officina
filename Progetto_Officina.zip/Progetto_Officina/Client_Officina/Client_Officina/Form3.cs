﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client_Officina
{
    public partial class Form3 : Form
    {
        private Socket senderSocket;

        public Form3(Socket socket)
        {
            InitializeComponent();
            senderSocket = socket;
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void BTN_return_Click(object sender, EventArgs e)
        {
            // Torna a Form2 passando il socket corrente
            Form2 form2 = new Form2(senderSocket);
            form2.Show();
            this.Hide(); // Nasconde Form3
        }

        private void BTN_RicaricaConto_Click(object sender, EventArgs e)
        {

        }
    }
}
