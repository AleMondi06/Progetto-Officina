﻿namespace Client_Officina
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTN_return = new System.Windows.Forms.Button();
            this.BTN_RicaricaConto = new System.Windows.Forms.Button();
            this.Box_Importo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.BTN_VisConto = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BTN_return
            // 
            this.BTN_return.Location = new System.Drawing.Point(136, 166);
            this.BTN_return.Name = "BTN_return";
            this.BTN_return.Size = new System.Drawing.Size(100, 78);
            this.BTN_return.TabIndex = 28;
            this.BTN_return.Text = "Ritorna alla Officina";
            this.BTN_return.UseVisualStyleBackColor = true;
            this.BTN_return.Click += new System.EventHandler(this.BTN_return_Click);
            // 
            // BTN_RicaricaConto
            // 
            this.BTN_RicaricaConto.Location = new System.Drawing.Point(16, 43);
            this.BTN_RicaricaConto.Name = "BTN_RicaricaConto";
            this.BTN_RicaricaConto.Size = new System.Drawing.Size(100, 78);
            this.BTN_RicaricaConto.TabIndex = 29;
            this.BTN_RicaricaConto.Text = "Ricarica Conto";
            this.BTN_RicaricaConto.UseVisualStyleBackColor = true;
            this.BTN_RicaricaConto.Click += new System.EventHandler(this.BTN_RicaricaConto_Click);
            // 
            // Box_Importo
            // 
            this.Box_Importo.Location = new System.Drawing.Point(122, 73);
            this.Box_Importo.Name = "Box_Importo";
            this.Box_Importo.Size = new System.Drawing.Size(128, 20);
            this.Box_Importo.TabIndex = 30;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(119, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 31;
            this.label4.Text = "Inserisci Importo:";
            // 
            // BTN_VisConto
            // 
            this.BTN_VisConto.Location = new System.Drawing.Point(265, 43);
            this.BTN_VisConto.Name = "BTN_VisConto";
            this.BTN_VisConto.Size = new System.Drawing.Size(99, 78);
            this.BTN_VisConto.TabIndex = 32;
            this.BTN_VisConto.Text = "Visualizza Conto";
            this.BTN_VisConto.UseVisualStyleBackColor = true;
            this.BTN_VisConto.Click += new System.EventHandler(this.BTN_VisConto_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(95, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(155, 24);
            this.label6.TabIndex = 38;
            this.label6.Text = "AREA UTENTE";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(387, 275);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.BTN_VisConto);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Box_Importo);
            this.Controls.Add(this.BTN_RicaricaConto);
            this.Controls.Add(this.BTN_return);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTN_return;
        private System.Windows.Forms.Button BTN_RicaricaConto;
        private System.Windows.Forms.TextBox Box_Importo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BTN_VisConto;
        private System.Windows.Forms.Label label6;
    }
}