﻿namespace Client_Officina
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.Componentipanel = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.VetroButton = new System.Windows.Forms.Button();
            this.SpieButton = new System.Windows.Forms.Button();
            this.RuoteButton = new System.Windows.Forms.Button();
            this.SospensioniButton = new System.Windows.Forms.Button();
            this.FreniButton = new System.Windows.Forms.Button();
            this.MotoreButton = new System.Windows.Forms.Button();
            this.SterzoButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Exit_Client = new System.Windows.Forms.Button();
            this.Open_Client = new System.Windows.Forms.Button();
            this.Componentipanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Componentipanel
            // 
            this.Componentipanel.CausesValidation = false;
            this.Componentipanel.Controls.Add(this.label8);
            this.Componentipanel.Controls.Add(this.label7);
            this.Componentipanel.Controls.Add(this.label6);
            this.Componentipanel.Controls.Add(this.label5);
            this.Componentipanel.Controls.Add(this.label4);
            this.Componentipanel.Controls.Add(this.label3);
            this.Componentipanel.Controls.Add(this.label2);
            this.Componentipanel.Controls.Add(this.VetroButton);
            this.Componentipanel.Controls.Add(this.SpieButton);
            this.Componentipanel.Controls.Add(this.RuoteButton);
            this.Componentipanel.Controls.Add(this.SospensioniButton);
            this.Componentipanel.Controls.Add(this.FreniButton);
            this.Componentipanel.Controls.Add(this.MotoreButton);
            this.Componentipanel.Controls.Add(this.SterzoButton);
            this.Componentipanel.Location = new System.Drawing.Point(26, 28);
            this.Componentipanel.Name = "Componentipanel";
            this.Componentipanel.Size = new System.Drawing.Size(849, 343);
            this.Componentipanel.TabIndex = 25;
            this.Componentipanel.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(306, 151);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Prezzo:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(69, 151);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Prezzo:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(731, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Prezzo:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(540, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Prezzo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(368, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Prezzo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(199, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Prezzo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Prezzo:";
            // 
            // VetroButton
            // 
            this.VetroButton.BackgroundImage = global::Client_Officina.Properties.Resources.VetroAuto;
            this.VetroButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.VetroButton.Location = new System.Drawing.Point(233, 178);
            this.VetroButton.Name = "VetroButton";
            this.VetroButton.Size = new System.Drawing.Size(210, 129);
            this.VetroButton.TabIndex = 13;
            this.VetroButton.UseVisualStyleBackColor = true;
            // 
            // SpieButton
            // 
            this.SpieButton.BackgroundImage = global::Client_Officina.Properties.Resources.SpieAuto;
            this.SpieButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SpieButton.Location = new System.Drawing.Point(11, 178);
            this.SpieButton.Name = "SpieButton";
            this.SpieButton.Size = new System.Drawing.Size(210, 129);
            this.SpieButton.TabIndex = 12;
            this.SpieButton.UseVisualStyleBackColor = true;
            // 
            // RuoteButton
            // 
            this.RuoteButton.BackgroundImage = global::Client_Officina.Properties.Resources.RuotaAuto;
            this.RuoteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RuoteButton.Location = new System.Drawing.Point(700, 39);
            this.RuoteButton.Name = "RuoteButton";
            this.RuoteButton.Size = new System.Drawing.Size(100, 100);
            this.RuoteButton.TabIndex = 11;
            this.RuoteButton.UseVisualStyleBackColor = true;
            // 
            // SospensioniButton
            // 
            this.SospensioniButton.BackgroundImage = global::Client_Officina.Properties.Resources.SospensioniAuto;
            this.SospensioniButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SospensioniButton.Location = new System.Drawing.Point(516, 39);
            this.SospensioniButton.Name = "SospensioniButton";
            this.SospensioniButton.Size = new System.Drawing.Size(100, 100);
            this.SospensioniButton.TabIndex = 10;
            this.SospensioniButton.UseVisualStyleBackColor = true;
            // 
            // FreniButton
            // 
            this.FreniButton.BackgroundImage = global::Client_Officina.Properties.Resources.FreniAuto;
            this.FreniButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.FreniButton.Location = new System.Drawing.Point(343, 39);
            this.FreniButton.Name = "FreniButton";
            this.FreniButton.Size = new System.Drawing.Size(100, 100);
            this.FreniButton.TabIndex = 9;
            this.FreniButton.UseVisualStyleBackColor = true;
            // 
            // MotoreButton
            // 
            this.MotoreButton.BackgroundImage = global::Client_Officina.Properties.Resources.MotoreAuto;
            this.MotoreButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.MotoreButton.Location = new System.Drawing.Point(11, 39);
            this.MotoreButton.Name = "MotoreButton";
            this.MotoreButton.Size = new System.Drawing.Size(100, 100);
            this.MotoreButton.TabIndex = 8;
            this.MotoreButton.UseVisualStyleBackColor = true;
            // 
            // SterzoButton
            // 
            this.SterzoButton.BackgroundImage = global::Client_Officina.Properties.Resources.SterzoAuto;
            this.SterzoButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SterzoButton.Location = new System.Drawing.Point(174, 39);
            this.SterzoButton.Name = "SterzoButton";
            this.SterzoButton.Size = new System.Drawing.Size(100, 100);
            this.SterzoButton.TabIndex = 7;
            this.SterzoButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(274, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(368, 13);
            this.label1.TabIndex = 24;
            this.label1.Text = "SCEGLI GLI ELEMENTI CHE VUOI SOTITUIRE/CAMBIARE/REVISIONRE";
            // 
            // Exit_Client
            // 
            this.Exit_Client.Location = new System.Drawing.Point(776, 402);
            this.Exit_Client.Name = "Exit_Client";
            this.Exit_Client.Size = new System.Drawing.Size(100, 78);
            this.Exit_Client.TabIndex = 23;
            this.Exit_Client.Text = "Esci Dalla Officina";
            this.Exit_Client.UseVisualStyleBackColor = true;
            this.Exit_Client.Click += new System.EventHandler(this.Exit_Client_Click);
            // 
            // Open_Client
            // 
            this.Open_Client.Location = new System.Drawing.Point(22, 402);
            this.Open_Client.Name = "Open_Client";
            this.Open_Client.Size = new System.Drawing.Size(100, 78);
            this.Open_Client.TabIndex = 22;
            this.Open_Client.Text = "Connettiti Alla Officina";
            this.Open_Client.UseVisualStyleBackColor = true;
            this.Open_Client.Click += new System.EventHandler(this.Open_Client_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 528);
            this.Controls.Add(this.Componentipanel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Exit_Client);
            this.Controls.Add(this.Open_Client);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Componentipanel.ResumeLayout(false);
            this.Componentipanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel Componentipanel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button VetroButton;
        private System.Windows.Forms.Button SpieButton;
        private System.Windows.Forms.Button RuoteButton;
        private System.Windows.Forms.Button SospensioniButton;
        private System.Windows.Forms.Button FreniButton;
        private System.Windows.Forms.Button MotoreButton;
        private System.Windows.Forms.Button SterzoButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Exit_Client;
        private System.Windows.Forms.Button Open_Client;
    }
}

