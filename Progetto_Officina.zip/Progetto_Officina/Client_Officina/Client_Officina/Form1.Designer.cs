﻿namespace Client_Officina
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.Open_Client = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TBNomeUtente = new System.Windows.Forms.TextBox();
            this.TBPassword = new System.Windows.Forms.TextBox();
            this.TBPasswordR = new System.Windows.Forms.TextBox();
            this.TBNomeUtenteR = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ButtonRegistrati = new System.Windows.Forms.Button();
            this.BTTNExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Open_Client
            // 
            this.Open_Client.Location = new System.Drawing.Point(122, 254);
            this.Open_Client.Name = "Open_Client";
            this.Open_Client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Open_Client.Size = new System.Drawing.Size(100, 78);
            this.Open_Client.TabIndex = 22;
            this.Open_Client.Text = "Connettiti Alla Officina";
            this.Open_Client.UseVisualStyleBackColor = true;
            this.Open_Client.Click += new System.EventHandler(this.Open_Client_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(99, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 23;
            this.label1.Text = "Nome utente";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(99, 153);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 24;
            this.label2.Text = "Password";
            // 
            // TBNomeUtente
            // 
            this.TBNomeUtente.Location = new System.Drawing.Point(102, 106);
            this.TBNomeUtente.Name = "TBNomeUtente";
            this.TBNomeUtente.Size = new System.Drawing.Size(120, 20);
            this.TBNomeUtente.TabIndex = 25;
            // 
            // TBPassword
            // 
            this.TBPassword.Location = new System.Drawing.Point(102, 187);
            this.TBPassword.Name = "TBPassword";
            this.TBPassword.Size = new System.Drawing.Size(120, 20);
            this.TBPassword.TabIndex = 26;
            // 
            // TBPasswordR
            // 
            this.TBPasswordR.Location = new System.Drawing.Point(630, 187);
            this.TBPasswordR.Name = "TBPasswordR";
            this.TBPasswordR.Size = new System.Drawing.Size(120, 20);
            this.TBPasswordR.TabIndex = 31;
            // 
            // TBNomeUtenteR
            // 
            this.TBNomeUtenteR.Location = new System.Drawing.Point(630, 106);
            this.TBNomeUtenteR.Name = "TBNomeUtenteR";
            this.TBNomeUtenteR.Size = new System.Drawing.Size(120, 20);
            this.TBNomeUtenteR.TabIndex = 30;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(627, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 29;
            this.label3.Text = "Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(627, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 28;
            this.label4.Text = "Nome utente";
            // 
            // ButtonRegistrati
            // 
            this.ButtonRegistrati.Location = new System.Drawing.Point(650, 254);
            this.ButtonRegistrati.Name = "ButtonRegistrati";
            this.ButtonRegistrati.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ButtonRegistrati.Size = new System.Drawing.Size(100, 78);
            this.ButtonRegistrati.TabIndex = 27;
            this.ButtonRegistrati.Text = "Registrati Alla Officina";
            this.ButtonRegistrati.UseVisualStyleBackColor = true;
            this.ButtonRegistrati.Click += new System.EventHandler(this.ButtonRegistrati_Click);
            // 
            // BTTNExit
            // 
            this.BTTNExit.Location = new System.Drawing.Point(389, 409);
            this.BTTNExit.Name = "BTTNExit";
            this.BTTNExit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.BTTNExit.Size = new System.Drawing.Size(100, 78);
            this.BTTNExit.TabIndex = 32;
            this.BTTNExit.Text = "ESCI";
            this.BTTNExit.UseVisualStyleBackColor = true;
            this.BTTNExit.Click += new System.EventHandler(this.BTTNExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(943, 528);
            this.Controls.Add(this.BTTNExit);
            this.Controls.Add(this.TBPasswordR);
            this.Controls.Add(this.TBNomeUtenteR);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ButtonRegistrati);
            this.Controls.Add(this.TBPassword);
            this.Controls.Add(this.TBNomeUtente);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Open_Client);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Open_Client;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TBNomeUtente;
        private System.Windows.Forms.TextBox TBPassword;
        private System.Windows.Forms.TextBox TBPasswordR;
        private System.Windows.Forms.TextBox TBNomeUtenteR;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button ButtonRegistrati;
        private System.Windows.Forms.Button BTTNExit;
    }
}

