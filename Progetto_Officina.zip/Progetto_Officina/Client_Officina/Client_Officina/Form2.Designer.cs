﻿namespace Client_Officina
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Exit_Client = new System.Windows.Forms.Button();
            this.BTN_AreaUtente = new System.Windows.Forms.Button();
            this.SterzoButton = new System.Windows.Forms.Button();
            this.MotoreButton = new System.Windows.Forms.Button();
            this.FreniButton = new System.Windows.Forms.Button();
            this.SospensioniButton = new System.Windows.Forms.Button();
            this.RuoteButton = new System.Windows.Forms.Button();
            this.SpieButton = new System.Windows.Forms.Button();
            this.VetroButton = new System.Windows.Forms.Button();
            this.PrezzoMotore = new System.Windows.Forms.Label();
            this.PrezzoSterzo = new System.Windows.Forms.Label();
            this.PrezzoFreni = new System.Windows.Forms.Label();
            this.PrezzoSospensioni = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.PrezzoSpie = new System.Windows.Forms.Label();
            this.PrezzoVetri = new System.Windows.Forms.Label();
            this.QuantitaMotore = new System.Windows.Forms.Label();
            this.QuantitaSterzo = new System.Windows.Forms.Label();
            this.QuantitaFreni = new System.Windows.Forms.Label();
            this.QuantitaSospensioni = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.QuantitaSpie = new System.Windows.Forms.Label();
            this.QuantitaVetri = new System.Windows.Forms.Label();
            this.CB_Servizio = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(228, 22);
            this.label1.TabIndex = 28;
            this.label1.Text = "SELEZIONA IL TUO SEVIZIO";
            // 
            // Exit_Client
            // 
            this.Exit_Client.Location = new System.Drawing.Point(750, 425);
            this.Exit_Client.Name = "Exit_Client";
            this.Exit_Client.Size = new System.Drawing.Size(100, 78);
            this.Exit_Client.TabIndex = 27;
            this.Exit_Client.Text = "Esci Dalla Officina";
            this.Exit_Client.UseVisualStyleBackColor = true;
            this.Exit_Client.Click += new System.EventHandler(this.Exit_Client_Click);
            // 
            // BTN_AreaUtente
            // 
            this.BTN_AreaUtente.Location = new System.Drawing.Point(33, 425);
            this.BTN_AreaUtente.Name = "BTN_AreaUtente";
            this.BTN_AreaUtente.Size = new System.Drawing.Size(100, 78);
            this.BTN_AreaUtente.TabIndex = 30;
            this.BTN_AreaUtente.Text = "Accedi area utente";
            this.BTN_AreaUtente.UseVisualStyleBackColor = true;
            this.BTN_AreaUtente.Click += new System.EventHandler(this.BTN_AreaUtente_Click);
            // 
            // SterzoButton
            // 
            this.SterzoButton.BackgroundImage = global::Client_Officina.Properties.Resources.SterzoAuto;
            this.SterzoButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SterzoButton.Location = new System.Drawing.Point(363, 108);
            this.SterzoButton.Name = "SterzoButton";
            this.SterzoButton.Size = new System.Drawing.Size(100, 100);
            this.SterzoButton.TabIndex = 7;
            this.SterzoButton.UseVisualStyleBackColor = true;
            this.SterzoButton.Click += new System.EventHandler(this.SterzoButton_Click);
            // 
            // MotoreButton
            // 
            this.MotoreButton.BackgroundImage = global::Client_Officina.Properties.Resources.MotoreAuto;
            this.MotoreButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.MotoreButton.Location = new System.Drawing.Point(200, 108);
            this.MotoreButton.Name = "MotoreButton";
            this.MotoreButton.Size = new System.Drawing.Size(100, 100);
            this.MotoreButton.TabIndex = 8;
            this.MotoreButton.UseVisualStyleBackColor = true;
            this.MotoreButton.Click += new System.EventHandler(this.MotoreButton_Click);
            // 
            // FreniButton
            // 
            this.FreniButton.BackgroundImage = global::Client_Officina.Properties.Resources.FreniAuto;
            this.FreniButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.FreniButton.Location = new System.Drawing.Point(532, 108);
            this.FreniButton.Name = "FreniButton";
            this.FreniButton.Size = new System.Drawing.Size(100, 100);
            this.FreniButton.TabIndex = 9;
            this.FreniButton.UseVisualStyleBackColor = true;
            this.FreniButton.Click += new System.EventHandler(this.FreniButton_Click);
            // 
            // SospensioniButton
            // 
            this.SospensioniButton.BackgroundImage = global::Client_Officina.Properties.Resources.SospensioniAuto;
            this.SospensioniButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SospensioniButton.Location = new System.Drawing.Point(705, 108);
            this.SospensioniButton.Name = "SospensioniButton";
            this.SospensioniButton.Size = new System.Drawing.Size(100, 100);
            this.SospensioniButton.TabIndex = 10;
            this.SospensioniButton.UseVisualStyleBackColor = true;
            this.SospensioniButton.Click += new System.EventHandler(this.SospensioniButton_Click);
            // 
            // RuoteButton
            // 
            this.RuoteButton.BackgroundImage = global::Client_Officina.Properties.Resources.RuotaAuto;
            this.RuoteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RuoteButton.Location = new System.Drawing.Point(1602, 171);
            this.RuoteButton.Name = "RuoteButton";
            this.RuoteButton.Size = new System.Drawing.Size(100, 100);
            this.RuoteButton.TabIndex = 11;
            this.RuoteButton.UseVisualStyleBackColor = true;
            // 
            // SpieButton
            // 
            this.SpieButton.BackColor = System.Drawing.SystemColors.GrayText;
            this.SpieButton.BackgroundImage = global::Client_Officina.Properties.Resources.SpieAuto;
            this.SpieButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SpieButton.Location = new System.Drawing.Point(234, 262);
            this.SpieButton.Margin = new System.Windows.Forms.Padding(0);
            this.SpieButton.Name = "SpieButton";
            this.SpieButton.Size = new System.Drawing.Size(210, 129);
            this.SpieButton.TabIndex = 12;
            this.SpieButton.UseVisualStyleBackColor = false;
            this.SpieButton.Click += new System.EventHandler(this.SpieButton_Click);
            // 
            // VetroButton
            // 
            this.VetroButton.BackgroundImage = global::Client_Officina.Properties.Resources.VetroAuto;
            this.VetroButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.VetroButton.Location = new System.Drawing.Point(561, 262);
            this.VetroButton.Name = "VetroButton";
            this.VetroButton.Size = new System.Drawing.Size(210, 129);
            this.VetroButton.TabIndex = 13;
            this.VetroButton.UseVisualStyleBackColor = true;
            this.VetroButton.Click += new System.EventHandler(this.VetroButton_Click);
            // 
            // PrezzoMotore
            // 
            this.PrezzoMotore.AutoSize = true;
            this.PrezzoMotore.Location = new System.Drawing.Point(231, 82);
            this.PrezzoMotore.Name = "PrezzoMotore";
            this.PrezzoMotore.Size = new System.Drawing.Size(42, 13);
            this.PrezzoMotore.TabIndex = 14;
            this.PrezzoMotore.Text = "Prezzo:";
            // 
            // PrezzoSterzo
            // 
            this.PrezzoSterzo.AutoSize = true;
            this.PrezzoSterzo.Location = new System.Drawing.Point(388, 82);
            this.PrezzoSterzo.Name = "PrezzoSterzo";
            this.PrezzoSterzo.Size = new System.Drawing.Size(42, 13);
            this.PrezzoSterzo.TabIndex = 15;
            this.PrezzoSterzo.Text = "Prezzo:";
            // 
            // PrezzoFreni
            // 
            this.PrezzoFreni.AutoSize = true;
            this.PrezzoFreni.Location = new System.Drawing.Point(557, 82);
            this.PrezzoFreni.Name = "PrezzoFreni";
            this.PrezzoFreni.Size = new System.Drawing.Size(42, 13);
            this.PrezzoFreni.TabIndex = 16;
            this.PrezzoFreni.Text = "Prezzo:";
            // 
            // PrezzoSospensioni
            // 
            this.PrezzoSospensioni.AutoSize = true;
            this.PrezzoSospensioni.Location = new System.Drawing.Point(729, 82);
            this.PrezzoSospensioni.Name = "PrezzoSospensioni";
            this.PrezzoSospensioni.Size = new System.Drawing.Size(42, 13);
            this.PrezzoSospensioni.TabIndex = 17;
            this.PrezzoSospensioni.Text = "Prezzo:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1633, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Prezzo:";
            // 
            // PrezzoSpie
            // 
            this.PrezzoSpie.AutoSize = true;
            this.PrezzoSpie.Location = new System.Drawing.Point(317, 233);
            this.PrezzoSpie.Name = "PrezzoSpie";
            this.PrezzoSpie.Size = new System.Drawing.Size(42, 13);
            this.PrezzoSpie.TabIndex = 19;
            this.PrezzoSpie.Text = "Prezzo:";
            // 
            // PrezzoVetri
            // 
            this.PrezzoVetri.AutoSize = true;
            this.PrezzoVetri.Location = new System.Drawing.Point(640, 233);
            this.PrezzoVetri.Name = "PrezzoVetri";
            this.PrezzoVetri.Size = new System.Drawing.Size(42, 13);
            this.PrezzoVetri.TabIndex = 20;
            this.PrezzoVetri.Text = "Prezzo:";
            // 
            // QuantitaMotore
            // 
            this.QuantitaMotore.AutoSize = true;
            this.QuantitaMotore.Location = new System.Drawing.Point(231, 95);
            this.QuantitaMotore.Name = "QuantitaMotore";
            this.QuantitaMotore.Size = new System.Drawing.Size(50, 13);
            this.QuantitaMotore.TabIndex = 21;
            this.QuantitaMotore.Text = "Quantità:";
            // 
            // QuantitaSterzo
            // 
            this.QuantitaSterzo.AutoSize = true;
            this.QuantitaSterzo.Location = new System.Drawing.Point(388, 95);
            this.QuantitaSterzo.Name = "QuantitaSterzo";
            this.QuantitaSterzo.Size = new System.Drawing.Size(50, 13);
            this.QuantitaSterzo.TabIndex = 22;
            this.QuantitaSterzo.Text = "Quantità:";
            // 
            // QuantitaFreni
            // 
            this.QuantitaFreni.AutoSize = true;
            this.QuantitaFreni.Location = new System.Drawing.Point(557, 95);
            this.QuantitaFreni.Name = "QuantitaFreni";
            this.QuantitaFreni.Size = new System.Drawing.Size(50, 13);
            this.QuantitaFreni.TabIndex = 23;
            this.QuantitaFreni.Text = "Quantità:";
            // 
            // QuantitaSospensioni
            // 
            this.QuantitaSospensioni.AutoSize = true;
            this.QuantitaSospensioni.Location = new System.Drawing.Point(729, 95);
            this.QuantitaSospensioni.Name = "QuantitaSospensioni";
            this.QuantitaSospensioni.Size = new System.Drawing.Size(50, 13);
            this.QuantitaSospensioni.TabIndex = 24;
            this.QuantitaSospensioni.Text = "Quantità:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1633, 158);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 13);
            this.label13.TabIndex = 25;
            this.label13.Text = "Quantità:";
            // 
            // QuantitaSpie
            // 
            this.QuantitaSpie.AutoSize = true;
            this.QuantitaSpie.Location = new System.Drawing.Point(317, 246);
            this.QuantitaSpie.Name = "QuantitaSpie";
            this.QuantitaSpie.Size = new System.Drawing.Size(50, 13);
            this.QuantitaSpie.TabIndex = 26;
            this.QuantitaSpie.Text = "Quantità:";
            // 
            // QuantitaVetri
            // 
            this.QuantitaVetri.AutoSize = true;
            this.QuantitaVetri.Location = new System.Drawing.Point(640, 246);
            this.QuantitaVetri.Name = "QuantitaVetri";
            this.QuantitaVetri.Size = new System.Drawing.Size(50, 13);
            this.QuantitaVetri.TabIndex = 27;
            this.QuantitaVetri.Text = "Quantità:";
            // 
            // CB_Servizio
            // 
            this.CB_Servizio.FormattingEnabled = true;
            this.CB_Servizio.Location = new System.Drawing.Point(12, 66);
            this.CB_Servizio.Name = "CB_Servizio";
            this.CB_Servizio.Size = new System.Drawing.Size(121, 21);
            this.CB_Servizio.TabIndex = 31;
            this.CB_Servizio.SelectedIndexChanged += new System.EventHandler(this.CB_Servizio_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(219, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 19);
            this.label2.TabIndex = 32;
            this.label2.Text = "MOTORE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(387, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 19);
            this.label3.TabIndex = 33;
            this.label3.Text = "STERZO";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(528, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 19);
            this.label4.TabIndex = 34;
            this.label4.Text = "IMPIANTO FRENI";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(711, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 19);
            this.label5.TabIndex = 35;
            this.label5.Text = "SOSPENSIONI";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(284, 214);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(116, 19);
            this.label7.TabIndex = 36;
            this.label7.Text = "SPIE GENERICHE";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(641, 214);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 19);
            this.label8.TabIndex = 37;
            this.label8.Text = "VETRI";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(908, 555);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CB_Servizio);
            this.Controls.Add(this.QuantitaVetri);
            this.Controls.Add(this.BTN_AreaUtente);
            this.Controls.Add(this.QuantitaSpie);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.QuantitaSospensioni);
            this.Controls.Add(this.Exit_Client);
            this.Controls.Add(this.QuantitaFreni);
            this.Controls.Add(this.MotoreButton);
            this.Controls.Add(this.QuantitaSterzo);
            this.Controls.Add(this.SterzoButton);
            this.Controls.Add(this.QuantitaMotore);
            this.Controls.Add(this.FreniButton);
            this.Controls.Add(this.PrezzoVetri);
            this.Controls.Add(this.SospensioniButton);
            this.Controls.Add(this.PrezzoSpie);
            this.Controls.Add(this.RuoteButton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.SpieButton);
            this.Controls.Add(this.PrezzoSospensioni);
            this.Controls.Add(this.VetroButton);
            this.Controls.Add(this.PrezzoFreni);
            this.Controls.Add(this.PrezzoMotore);
            this.Controls.Add(this.PrezzoSterzo);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Exit_Client;
        private System.Windows.Forms.Button BTN_AreaUtente;
        private System.Windows.Forms.Button SterzoButton;
        private System.Windows.Forms.Button MotoreButton;
        private System.Windows.Forms.Button FreniButton;
        private System.Windows.Forms.Button SospensioniButton;
        private System.Windows.Forms.Button RuoteButton;
        private System.Windows.Forms.Button SpieButton;
        private System.Windows.Forms.Button VetroButton;
        private System.Windows.Forms.Label PrezzoMotore;
        private System.Windows.Forms.Label PrezzoSterzo;
        private System.Windows.Forms.Label PrezzoFreni;
        private System.Windows.Forms.Label PrezzoSospensioni;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label PrezzoSpie;
        private System.Windows.Forms.Label PrezzoVetri;
        private System.Windows.Forms.Label QuantitaMotore;
        private System.Windows.Forms.Label QuantitaSterzo;
        private System.Windows.Forms.Label QuantitaFreni;
        private System.Windows.Forms.Label QuantitaSospensioni;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label QuantitaSpie;
        private System.Windows.Forms.Label QuantitaVetri;
        private System.Windows.Forms.ComboBox CB_Servizio;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}