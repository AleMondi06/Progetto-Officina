﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace Client_Officina
{
    public partial class Form1 : Form
    {
        private Socket senderSocket; // Variabile per il socket del client

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Exit_Client.Visible = false;
            Open_Client.Visible = true;
            Componentipanel.Visible = false;
        }

        private void Open_Client_Click(object sender, EventArgs e)
        {
            try
            {
                // Indirizzo IP e porta del server
                IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
                IPEndPoint remoteEP = new IPEndPoint(ipAddress, 5000);

                // Creazione del socket per la connessione al server
                senderSocket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                senderSocket.Connect(remoteEP);

                MessageBox.Show("Connessione stabilita con il server");
                Exit_Client.Visible = true;
                Open_Client.Visible = false;
                Componentipanel.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la connessione: " + ex.Message);
            }
        }

        private void Exit_Client_Click(object sender, EventArgs e)
        {
            try
            {
                if (senderSocket != null && senderSocket.Connected)
                {
                    // Invia un messaggio di chiusura al server
                    byte[] closeMsg = Encoding.ASCII.GetBytes("ChiudiConnessione");
                    senderSocket.Send(closeMsg);

                    // Chiude la connessione
                    senderSocket.Shutdown(SocketShutdown.Both);
                    senderSocket.Close();
                    senderSocket = null; // Resetta il socket
                    MessageBox.Show("Connessione chiusa con il server");
                }

                Exit_Client.Visible = false;
                Open_Client.Visible = true;
                Componentipanel.Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la chiusura della connessione: " + ex.Message);
            }
        }
    }
}
