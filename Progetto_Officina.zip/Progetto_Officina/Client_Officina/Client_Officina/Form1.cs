﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace Client_Officina
{
    public partial class Form1 : Form
    {
        private Socket senderSocket;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
                IPEndPoint remoteEP = new IPEndPoint(ipAddress, 5000);

                senderSocket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                senderSocket.Connect(remoteEP);
                MessageBox.Show("Connessione stabilita con il server");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la connessione: " + ex.Message);
            }
        }

        private void Open_Client_Click(object sender, EventArgs e)
        {
            string username = TBNomeUtente.Text;
            string password = TBPassword.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Inserisci sia nome utente che password.");
                return;
            }

            // Prepara il messaggio di login e lo invia al server
            string loginData = $"Login:{username};{password}";
            byte[] msg = Encoding.ASCII.GetBytes(loginData);

            try
            {
                senderSocket.Send(msg);

                byte[] bytes = new byte[1024];
                int bytesRec = senderSocket.Receive(bytes);
                string response = Encoding.ASCII.GetString(bytes, 0, bytesRec);

                if (response == "LoginSuccesso")
                {
                    MessageBox.Show("Accesso eseguito con successo!");
                    Form2 form2 = new Form2(senderSocket, username); // Passa il nome utente
                    form2.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Nome utente o password non corretti.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante il login: " + ex.Message);
            }
        }

            private void ButtonRegistrati_Click(object sender, EventArgs e)
        {
            string usernamer = TBNomeUtenteR.Text;
            string passwordr = TBPasswordR.Text;
            int saldoIniziale = 0;

            if (string.IsNullOrWhiteSpace(usernamer) || string.IsNullOrWhiteSpace(passwordr))
            {
                MessageBox.Show("Inserisci sia nome utente che password.");
                return;
            }

            string userData = $"{usernamer};{passwordr};{saldoIniziale}";
            byte[] msg = Encoding.ASCII.GetBytes(userData);

            try
            {
                senderSocket.Send(msg);
                MessageBox.Show("Registrazione inviata al server!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante l'invio della registrazione: " + ex.Message);
            }

            TBNomeUtenteR.Clear();
            TBPasswordR.Clear();
        }

        private void BTTNExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
