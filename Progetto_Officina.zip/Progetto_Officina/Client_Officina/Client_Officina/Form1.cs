﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace Client_Officina
{
    public partial class Form1 : Form
    {
        private Socket senderSocket; // Variabile per il socket del client

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // Indirizzo IP e porta del server
                IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
                IPEndPoint remoteEP = new IPEndPoint(ipAddress, 5000);

                // Creazione del socket per la connessione al server
                senderSocket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                // Tentativo di connessione
                senderSocket.Connect(remoteEP);
                MessageBox.Show("Connessione stabilita con il server");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la connessione: " + ex.Message);
            }
        }

        private void Open_Client_Click(object sender, EventArgs e)
        {                
            // Apertura di Form2 con il socket e nasconde Form1
            Form2 form2 = new Form2(senderSocket);
            form2.Show();
            this.Hide();
        }

        private void ButtonRegistrati_Click(object sender, EventArgs e)
        {
            // Ottieni i valori da TBNomeUtenteR e TBPasswordR
            string username = TBNomeUtenteR.Text;
            string password = TBPasswordR.Text;
            int saldoIniziale = 0;  // Saldo iniziale

            // Controlla che entrambi i campi non siano vuoti
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Inserisci sia nome utente che password.");
                return;
            }

            // Formatta la stringa da salvare nel file con saldo iniziale
            string userData = $"{username};{password};{saldoIniziale}";

            try
            {
                // Percorso completo del file di testo
                string filePath = @"..\..\Resources\Datiutenti.txt";

                // Utilizza StreamWriter per salvare i dati aggiungendo una nuova riga al file
                using (StreamWriter writer = new StreamWriter(filePath, append: true))
                {
                    writer.WriteLine(userData);
                }

                MessageBox.Show("Registrazione completata!");

                // Pulisci i campi di testo dopo la registrazione
                TBNomeUtenteR.Clear();
                TBPasswordR.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la registrazione: " + ex.Message);
            }
        }

        private void BTTNExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
